from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.http import JsonResponse, HttpResponse
import requests
# Create your views here.

from .models import Summoner

from .serializers import SummonerSerializer

from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer

def getSummoner(request,region,user):
    data = requests.get("https://"+str(region)+".api.riotgames.com/lol/summoner/v4/summoners/by-name/"+str(user)+'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()
    return JsonResponse(data)

def getNeededData(request,region,summonername):
    array = []
    summonerid = requests.get("https://"+str(region)+".api.riotgames.com/lol/summoner/v4/summoners/by-name/" + str(summonername) + '?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()
    if "accountId" in summonerid:
        matches = requests.get("https://"+str(region)+".api.riotgames.com/lol/match/v4/matchlists/by-account/" + str(summonerid["accountId"]) + '?endIndex=10&api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()
        if "matches" in matches:
            for match in matches['matches']:
                data = {}
                matchDTO = requests.get("https://"+str(region)+".api.riotgames.com/lol/match/v4/matches/"+str(match['gameId'])+'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()
                for player in matchDTO['participantIdentities']:
                    if player['player']['summonerName'] == summonername:
                        data['player'] = player
                        for playerDTO in matchDTO['participants']:
                            if playerDTO['participantId'] == player['participantId']:
                                data['playerDTO'] = playerDTO
                                data['matchDTO'] = matchDTO
                                break
                array.append(data)
            return JsonResponse(array, safe=False)
        else:
            return JsonResponse({"Data":"Missing Data"})
    return JsonResponse({"Data":"No player"})

def getSummonerByName(name):
    data = requests.get("https://euw1.api.riotgames.com/lol/summoner/v4/summoners/by-name/"+str('Lutherion')+'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()
    return JsonResponse(data)

def getSummonerIdByName(name):
    data = requests.get("https://euw1.api.riotgames.com/lol/summoner/v4/summoners/by-name/" +str('Lutherion')+'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()["id"]
    return JsonResponse(data)

def getSummonerAccountIdByName(name):
    data = requests.get("https://euw1.api.riotgames.com/lol/summoner/v4/summoners/by-name/" +str('Lutherion')+'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()["accountId"]
    return JsonResponse(data)

def getSummonerAccountNameByName(name):
    data = requests.get("https://euw1.api.riotgames.com/lol/summoner/v4/summoners/by-name/" +str('Lutherion')+'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()["name"]
    return JsonResponse(data)

def getSummonerAccountProfileIconByName(name):
    data = requests.get("https://euw1.api.riotgames.com/lol/summoner/v4/summoners/by-name/" +str('Lutherion')+'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()["profileIconId"]
    return JsonResponse(data)

def getEntriesBySummonerId(id):
    data = requests.get("https://euw1.api.riotgames.com/lol/league/v4/entries/by-summoner/"+str(id)+'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3')
    return JsonResponse(data)

def getMatchesByAccountId(request,region,accountId):
    data = requests.get("https://"+str(region)+".api.riotgames.com/lol/match/v4/matchlists/by-account/"+str(accountId)+"?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3").json()
    return JsonResponse(data)

def getMatchByGameId(gameId):
    data = requests.get("https://euw1.api.riotgames.com/lol/match/v4/matches/"+str(gameId) +'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()
    return JsonResponse(data)

def getMatchParticipantIdentitiesByGameId(gameId):
    data = requests.get("https://euw1.api.riotgames.com/lol/match/v4/matches/"+str(gameId) +'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()["participantIdentities"]
    return JsonResponse(data)

def getMatchStatsOfPlayer(name,gameId):
    id = None
    player = None
    for x in getMatchByGameId(gameId)["participantIdentities"]:
        if x["player"]["summonerName"] == name:
            id = x["participantId"]
            break
    for y in getMatchByGameId(gameId)["participants"]:
        if y["participantId"] == id:
            player = y
    return player

def getPlayerIdFromMatch(name,gameId):
    id = None
    for x in getMatchByGameId(gameId)["participantIdentities"]:
        if x["player"]["summonerName"] == name:
            id = x["participantId"]
    return id

def getKDA(gameId,participantId):
    kda = None
    for y in getMatchByGameId(gameId)["participants"]:
        if y["participantId"] == participantId:
            kda = str(y["stats"]["kills"])+"/"+str(y["stats"]["deaths"])+"/"+str(y["stats"]["assists"])
    return kda

def getWinLose(gameId,participantId):
    WL = None
    for y in getMatchByGameId(gameId)["participants"]:
        if y["participantId"] == participantId:
            WL = str(y["stats"]["win"])
    return WL

def getRanksBySummonerID(summonerId):
    data = requests.get("https://euw1.api.riotgames.com/lol/league/v4/entries/by-summoner/"+str(summonerId) +'?api_key=RGAPI-2d6940db-ec33-40de-a092-12ce4fd439e3').json()
    return JsonResponse(data)