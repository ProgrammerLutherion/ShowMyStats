from django.db import models

# Create your models here.
class Summoner(models.Model):
    accountId = models.CharField(max_length=250)
    profileIconId = models.IntegerField()
    revisionDate = models.CharField(max_length=250)
    name = models.CharField(max_length=250)
    sID = models.CharField(max_length=250)
    puuid = models.CharField(max_length=250)
    summonerLevel = models.CharField(max_length=250)

    def __str__(self):
        return self.name
