from django.apps import AppConfig


class BackapiConfig(AppConfig):
    name = 'backapi'
