import { NeededData } from './../needed-data';
import { MatchDTO } from './../match-dto';
import { Matches } from './../matches';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { Summoner } from '../summoner';
import { GetLolDataService } from './../get-lol-data.service';
import { range } from 'rxjs';
import { NavController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
@Component({
  selector: 'app-matches',
  templateUrl: './matches.page.html',
  styleUrls: ['./matches.page.scss'],
})
export class MatchesPage implements OnInit {

  summonername: any;
  region: any = "euw1";

  sliderConfig = {
    direction: 'vertical',
    slidesPerView: 1,
  };

  constructor(private loldata: GetLolDataService,private route: ActivatedRoute,private router: Router,private navCtrl: NavController,public alertController: AlertController) {
    this.route.queryParams.subscribe(params => {
      if(params && params.user){
        this.summonername = params.user;
      }
      if(params && params.region){
        this.region = params.region;
      }
    })
  }

  moredata = false
  summoner: Summoner[] = [];
  matches: any;
  matchesArray: Matches[] = [];
  allNeededDataMatches: NeededData[] = [];
  noOfItem = 1

  getImage(winlose,map){
    if(winlose == true){
      if(map == 12){
        return "../../assets/icon/icon-victory.png"
      }
      else{
        return "../../assets/icon/icon-victory (1).png"
      }
    }
    if(winlose == false){
      if(map == 12){
        return "../../assets/icon/icon-defeat.png"
      }
      else{
        return "../../assets/icon/icon-defeat (1).png"
      }
    }
  }

  cardClick(){
    if(this.moredata == false){
      this.moredata = true
    }else{
      this.moredata = false
    }
  }

  goBack(){
    this.navCtrl.navigateBack('/home')
  }

  async presentNoPlayerAlert() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'No player Data Found',
      message: 'There is no player named:'+this.summonername,
      buttons: [{
        text:'OK',
        handler: () => {
          this.router.navigate(['home'])
        }
      }]
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    console.log('onDidDismiss resolved with role', role);
  }

  async presentNoDataAlert() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'No player Data Found',
      message: 'There is no recent games for the summoner:'+this.summonername,
      buttons: [{
        text:'OK',
        handler: () => {
          this.router.navigate(['home'])
        }
      }]
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    console.log('onDidDismiss resolved with role', role);
  }

  getNeededDataService():void{
    this.loldata.getNeededData(this.region,this.summonername).subscribe(data =>{
        this.allNeededDataMatches = data;
        console.log(data)
        if(data['Data'] == "No player"){
          this.presentNoPlayerAlert()
        }
        else if(data['Data'] == "No data"){

        }
    })
  }

  ngOnInit() {
    if(this.summonername != undefined){
      this.getNeededDataService()
    }
  }

  findSummoner(){
    let navigationExtras: NavigationExtras = {
      queryParams: {
        user: this.summonername,
        region: this.region
      }
    }
    this.router.navigate(['matches'],navigationExtras)
  }
}
