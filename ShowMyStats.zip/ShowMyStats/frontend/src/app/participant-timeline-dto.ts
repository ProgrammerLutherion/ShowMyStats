import { Deltas } from "./deltas";

export interface ParticipantTimelineDTO {
  participantId:Int16Array,
  cdDiffPerMinDeltas: Deltas[],
  damageTakenPerMinDeltas:Deltas[],
  role:string,
  damageTakenDiffPerMinDeltas:Deltas[],
  xpPerMinDeltas:Deltas[],
  xpDiffPerMinDeltas:Deltas[],
  lane:string,
  creepsPerMinDeltas:Deltas[],
  goldPerMinDeltas:Deltas[]
}
