import { ParticipantDTO } from "./participant-dto";
import { ParticipantIdentityDTO } from "./participant-identity-dto";
import { TeamStatsDTO } from "./team-stats-dto";

export interface MatchDTO {
  gameId:string,
  participantIdentities:ParticipantIdentityDTO[],
  queueId:Int16Array,
  gameType:string,
  gameDuration:string,
  teams:TeamStatsDTO[],
  platformId:string,
  gameCreation:string,
  seasonId:Int16Array,
  gameVersion:string,
  mapId:Int16Array,
  gameMode:string,
  participants:ParticipantDTO[]
}
