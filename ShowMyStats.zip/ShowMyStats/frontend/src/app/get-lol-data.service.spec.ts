import { TestBed } from '@angular/core/testing';

import { GetLolDataService } from './get-lol-data.service';

describe('GetLolDataService', () => {
  let service: GetLolDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetLolDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
