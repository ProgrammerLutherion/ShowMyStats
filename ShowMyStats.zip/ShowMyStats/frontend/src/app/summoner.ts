import { logging } from "selenium-webdriver";

export interface Summoner {
    accountId:string,
    profileIconId:Int16Array,
    revisionDate:bigint,
    name:string,
    id:string,
    puuid:string,
    summonerLevel:bigint
}
