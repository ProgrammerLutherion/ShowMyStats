import { MasteryDTO } from "./mastery-dto";
import { ParticipantStatsDTO } from "./participant-stats-dto";
import { ParticipantTimelineDTO } from "./participant-timeline-dto";
import { RuneDTO } from "./rune-dto";

export interface ParticipantDTO {
  participantId:Int16Array,
  championId:Int16Array,
  runes:RuneDTO[],
  stats:ParticipantStatsDTO,
  teamId:Int16Array,
  timeline:ParticipantTimelineDTO,
  spell1Id:Int16Array,
  spell2Id:Int16Array,
  highestAchievedSeasonTier:string,
  masteries:MasteryDTO[]
}
