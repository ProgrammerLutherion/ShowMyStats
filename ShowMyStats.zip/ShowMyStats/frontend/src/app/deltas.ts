export interface Deltas {
  "10-20": number;
  "0-10": number;
}
