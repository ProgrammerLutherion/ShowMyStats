import { PlayerDTO } from "./player-dto";

export interface ParticipantIdentityDTO {
  participantId:Int16Array,
  player:PlayerDTO
}
