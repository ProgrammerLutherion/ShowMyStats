export interface RuneDTO {
  runeId:Int16Array,
  ranke:Int16Array
}
