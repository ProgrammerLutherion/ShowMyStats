import { TeamBansDTO } from "./team-bans-dto";

export interface TeamStatsDTO {
  towerKills:Int16Array,
  riftHeraldKills:Int16Array,
  firstBlood:boolean,
  inhibitorKills:Int16Array,
  bans:TeamBansDTO[],
  firstBaron:boolean,
  firstDragon:boolean,
  dominionVictoryScore:Int16Array,
  dragonKills:Int16Array,
  baronKills:Int16Array,
  firstInhibitor:boolean,
  firstTower:boolean,
  vilemawKills:Int16Array,
  firstRiftHerald:Int16Array,
  teamId:Int16Array,
  win:string
}
