import { NeededData } from './needed-data';
import { MatchDTO } from './match-dto';
import { Summoner } from './summoner';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Matches } from './matches';

@Injectable({
  providedIn: 'root'
})
export class GetLolDataService {


  constructor(private http: HttpClient) { }

  apikey = new HttpHeaders({"X-Riot-Token": "RGAPI-06e83bf8-65da-4f60-8080-d6c755e99129","Access-Control-Allow-Origin":"*"});
  key = "api_key=RGAPI-06e83bf8-65da-4f60-8080-d6c755e99129"



  getSummonerData(summonername,region):Observable<Summoner[]>{
    return this.http.get<Summoner[]>("http://127.0.0.1:8000/"+region+"/"+summonername+"/")
  }

  getSummonerMatches(accountID,region):Observable<Matches[]>{
    return this.http.get<Matches[]>("http://127.0.0.1:8000/summoner/matches/"+region+"/"+accountID+"/")
  }

  getNeededData(region,summonername):Observable<NeededData[]>{
      return this.http.get<NeededData[]>("http://127.0.0.1:8000/fulldata/"+region+"/"+summonername+"/")
  }

}
