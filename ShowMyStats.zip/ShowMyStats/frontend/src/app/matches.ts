import { Match } from './match';
export interface Matches {
  startIndex:Int16Array,
  totalGames:Int16Array,
  endIndex:Int16Array,
  matches:Match[],
}

