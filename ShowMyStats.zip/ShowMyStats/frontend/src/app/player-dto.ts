export interface PlayerDTO {
  profileIcon:Int16Array,
  accountId:string,
  matchHistoryUri:string,
  currentAccountId:string,
  currentPlatformId:string,
  summonerName:string,
  summonerId:string,
  platformId:string
}
