import { MatchDTO } from './match-dto';
import { ParticipantDTO } from './participant-dto';
import { PlayerDTO } from './player-dto';
export interface NeededData {
  player:PlayerDTO,
  playerDTO:ParticipantDTO,
  matchDTO:MatchDTO
}

