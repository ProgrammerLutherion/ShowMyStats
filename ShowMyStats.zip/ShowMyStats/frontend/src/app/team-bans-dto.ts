export interface TeamBansDTO {
  championId:Int16Array,
  pickTurn:Int16Array
}
