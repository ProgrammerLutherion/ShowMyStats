import { Summoner } from './../summoner';

import { Component } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor(private router: Router) {}

  summoner: Summoner[] = [];

  summonername: any;
  region: any = "euw1";





  findSummoner(){
    if (this.summonername){
      let navigationExtras: NavigationExtras = {
        queryParams: {
          user: this.summonername,
          region: this.region,
        }
      }
      this.router.navigate(['matches'],navigationExtras)
    }
  }




}
