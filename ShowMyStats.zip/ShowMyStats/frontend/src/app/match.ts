export interface Match {
  gameId:string,
  role:string,
  season:Int16Array,
  platformId:string,
  champion:Int16Array,
  queue:Int16Array,
  lane:string,
  timestamp:string,
}



