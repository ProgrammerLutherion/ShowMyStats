export interface MasteryDTO {
  rank:number,
  masteryId:number,
}
